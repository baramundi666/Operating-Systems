//
// Created by mateusz-krol on 3/1/24.
//
#include <stdio.h>

int main() {
    for(int i=10; i>=0; --i) {
        printf("%d\n", i);
    }
}
